// src/context/QuizContext.jsx
import { createContext, useReducer, useEffect } from "react";

export const NUM_Q = 12; // 문항 수에 맞춰 주세요

const freshAnswers = () => Array(NUM_Q).fill(null);

const initial = {
  lang: localStorage.getItem("lang") || "KOR",
  current: 0,
  answers: freshAnswers(),
  result: null,
};

function reducer(state, action){
  switch(action.type){
    case "SET_LANG":{
      const lang = action.payload;
      localStorage.setItem("lang", lang);
      return { ...state, lang };
    }

    // ✅ 언어 유지한 채 설문만 완전 초기화
    case "RESET":{
      const lang = state.lang;
      const next = { lang, current: 0, answers: freshAnswers(), result: null };
      localStorage.setItem("answers", JSON.stringify(next.answers));
      localStorage.removeItem("result");
      return next;
    }

    case "HYDRATE":{
      return { ...state, ...action.payload };
    }

    case "SET_ANSWER":{ // {index, value}
      const next = [...state.answers];
      next[action.index] = action.value;
      localStorage.setItem("answers", JSON.stringify(next));
      return { ...state, answers: next };
    }

    case "NEXT":{
      return { ...state, current: Math.min(state.current + 1, NUM_Q - 1) };
    }

    case "PREV":{
      return { ...state, current: Math.max(state.current - 1, 0) };
    }

    case "SET_RESULT":{
      localStorage.setItem("result", JSON.stringify(action.value));
      return { ...state, result: action.value };
    }

    default:
      return state;
  }
}

export const QuizContext = createContext({ state: initial, dispatch: () => {} });

export function QuizProvider({ children }){
  const [state, dispatch] = useReducer(reducer, initial);

  // 로컬스토리지 복구(길이가 다르면 강제 보정)
  useEffect(() => {
    try{
      const a = JSON.parse(localStorage.getItem("answers") || "null");
      const r = JSON.parse(localStorage.getItem("result") || "null");

      if(Array.isArray(a)){
        let arr = a.slice(0, NUM_Q);
        if (arr.length < NUM_Q) arr = arr.concat(Array(NUM_Q - arr.length).fill(null));
        dispatch({ type:"HYDRATE", payload:{ answers: arr }});
      }
      if(r) dispatch({ type:"HYDRATE", payload:{ result: r }});
    }catch(e){}
  }, []);

  return (
    <QuizContext.Provider value={{ state, dispatch }}>
      {children}
    </QuizContext.Provider>
  );
}
