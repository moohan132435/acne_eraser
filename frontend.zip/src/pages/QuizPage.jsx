import React, { useContext, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { QuizContext } from "../context/QuizContext.jsx";
import LanguageSwitcher from "../components/LanguageSwitcher.jsx";
import { API_BASE } from "../api/config";

const TOTAL_Q = 12;

// 각 문항별 보기 개수 (2번은 출생연도라 옵션 이미지 없음)
const OPTION_COUNT = {
  1: 4, 3: 4, 4: 4, 5: 4, 6: 4, 7: 4, 8: 4, 9: 4, 10: 4, 11: 4, 12: 4,
};

// 출생연도 후보
const YEARS = (() => {
  const now = new Date().getFullYear();
  const min = 1960;
  const max = Math.min(now - 8, 2015);
  const arr = [];
  for (let y = max; y >= min; y--) arr.push(y);
  return arr;
})();

export default function QuizPage() {
  const { state, dispatch } = useContext(QuizContext);
  const lang = state?.lang || "KOR";
  const navigate = useNavigate();

  // ✅ 방어: answers가 항상 배열이 되도록
  const answers =
    Array.isArray(state?.answers) && state.answers.length
      ? state.answers
      : Array(TOTAL_Q).fill(null);

  // ✅ 방어: current도 숫자로 강제
  const qIndex = Number.isInteger(state?.current) ? state.current : 0; // 0..11
  const qNo = qIndex + 1; // 1..12
  const genderAns = answers[0]; // 1=남, 2=여

  // 진행도 (답한 개수)
  const answeredCount = useMemo(
    () => answers.filter((v) => v !== null && v !== undefined).length,
    [answers]
  );
  const percent = Math.round((answeredCount / TOTAL_Q) * 100);

  const goPrev = () => {
    if (qIndex > 0) dispatch?.({ type: "PREV" });
  };

  const getOptionImg = (q, v) => {
    // 10번/12번은 성별 분기
    if ((q === 10 || q === 12) && (genderAns === 1 || genderAns === 2)) {
      const suffixGender = genderAns === 1 ? "_M" : "_W";
      const base = `/assets/option-${q}-${v}${suffixGender}`;
      return lang === "ENG" ? `${base}_eng.jpg` : `${base}.jpg`;
    }
    const base = `/assets/option-${q}-${v}`;
    return lang === "ENG" ? `${base}_eng.jpg` : `${base}.jpg`;
  };

  const submitResult = async (finalAnswers) => {
    const payload = { answers: finalAnswers };
    const res = await fetch(`${API_BASE}/api/result`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    const json = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(json?.detail || "Server error");
    dispatch?.({ type: "SET_RESULT", value: json });
    navigate("/result", { state: { result: json } });
  };

  const pick = async (value) => {
    // 현재 답 저장 (로컬스토리지 동기화는 리듀서가 수행)
    dispatch?.({ type: "SET_ANSWER", index: qIndex, value });
    const finalAnswers = answers.map((x, i) => (i === qIndex ? value : x));

    if (qNo === TOTAL_Q) {
      try {
        await submitResult(finalAnswers);
      } catch (e) {
        alert((lang === "ENG" ? "Result failed: " : "결과 계산 실패: ") + e.message);
      }
      return;
    }
    // 자동 다음
    dispatch?.({ type: "NEXT" });
  };

  const onBirthYear = (e) => {
    const s = e.target.value;
    const year = s ? parseInt(s, 10) : null;
    dispatch?.({ type: "SET_ANSWER", index: 1, value: year });
    if (year) dispatch?.({ type: "NEXT" });
  };

  return (
    <div className="page">
      <header className="topbar">
        <div className="brand">Spot Eraser</div>
        <LanguageSwitcher />
      </header>

      <div className="quiz-wrap">
        {/* 진행바 */}
        <div className="progress" aria-label="progress">
          <div style={{ width: `${percent}%` }} />
        </div>

        {/* 문제 카드 */}
        <div className="q-card">
          <img
            className="q-image"
            src={`/assets/quiz-question-${qNo}${lang === "ENG" ? "_eng" : ""}.jpg`}
            alt={`Q${qNo}`}
            loading="lazy"
          />

          {qNo === 2 ? (
            <div style={{ padding: 12 }}>
              <label style={{ fontWeight: 700, display: "block", marginBottom: 8 }}>
                {lang === "ENG" ? "Select your birth year" : "출생연도를 선택해 주세요"}
              </label>
              <select
                value={answers[1] ?? ""}
                onChange={onBirthYear}
                style={{
                  width: "100%",
                  height: 48,
                  borderRadius: 10,
                  border: "1px solid #e5e7eb",
                  padding: "0 12px",
                  fontSize: 16,
                }}
              >
                <option value="">{lang === "ENG" ? "Choose..." : "선택하세요"}</option>
                {YEARS.map((y) => (
                  <option key={y} value={y}>
                    {y}
                  </option>
                ))}
              </select>
            </div>
          ) : (
            <div className="opt-grid">
              {Array.from({ length: OPTION_COUNT[qNo] || 0 }).map((_, idx) => {
                const v = idx + 1;
                const selected = answers[qIndex] === v;
                return (
                  <button
                    key={v}
                    type="button"
                    className={`opt ${selected ? "selected" : ""}`}
                    onClick={() => pick(v)}
                  >
                    <img src={getOptionImg(qNo, v)} alt={`Q${qNo}-${v}`} loading="lazy" />
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* 맨 아래 중앙 Back 버튼 (Q1 제외) */}
        {qIndex > 0 && (
          <div className="quiz-bottom-actions" style={{ justifyContent: "center", marginBottom: 8 }}>
            <button className="btn btn-lg" onClick={goPrev}>
              {lang === "ENG" ? "← Back" : "← 뒤로가기"}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
