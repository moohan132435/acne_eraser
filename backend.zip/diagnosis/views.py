# backend/diagnosis/views.py
import json, logging, datetime
from typing import Any, Dict, List
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from . import quiz_logic

logger = logging.getLogger(__name__)

EXPECTED_Q = 12  # 설문 문항 수에 맞춰 조정 (예: 9 -> 12)

def _parse_request_body(request) -> Dict[str, Any]:
    """
    - application/json  : body 그대로 json.loads
    - 그 외(폼/빈바디)   : request.POST 에서 'answers'를 꺼내고, 문자열이면 json.loads 재시도
    - 완전 빈바디 대비
    """
    try:
        ct = (request.content_type or "").lower()
        if "application/json" in ct:
            raw = request.body or b"{}"
            return json.loads(raw.decode("utf-8"))
        else:
            data = request.POST.dict()
            if "answers" in data and isinstance(data["answers"], str):
                try:
                    data["answers"] = json.loads(data["answers"])
                except Exception:
                    pass
            return data
    except Exception:
        return {}

def _to_int_list(xs: Any) -> List[int]:
    if not isinstance(xs, list):
        raise ValueError("answers must be an array")
    out: List[int] = []
    for x in xs:
        if x is None:
            # 미응답은 0 으로 간주(혹은 그대로 None 허용하고 가중치 로직에서 무시하도록)
            out.append(0)
            continue
        try:
            out.append(int(x))
        except Exception:
            raise ValueError(f"non-integer answer: {x!r}")
    return out

@csrf_exempt
def result_view(request):
    if request.method != "POST":
        return JsonResponse({"detail": "Method not allowed"}, status=405)

    data = _parse_request_body(request)
    answers = data.get("answers")

    try:
        answers = _to_int_list(answers)
    except Exception as e:
        return JsonResponse({"detail": f"Invalid JSON: {e}"}, status=400)

    # 길이 보정(모자라면 0 채우기, 길면 잘라내기) — 프런트/백 문항수 불일치 방지
    if len(answers) < EXPECTED_Q:
        answers = answers + [0] * (EXPECTED_Q - len(answers))
    elif len(answers) > EXPECTED_Q:
        answers = answers[:EXPECTED_Q]

    try:
        result = quiz_logic.compute_result(answers)
    except ValueError as e:
        return JsonResponse({"detail": str(e)}, status=400)
    except Exception as e:
        logger.exception("compute_result failed")
        return JsonResponse({"detail": f"internal error: {e}"}, status=500)

    a_type = result.get("a_type")
    b_type = result.get("b_type")
    code   = result.get("code")
    scores = result.get("scores")
    image  = f"/assets/result-{code}.png" if code else "/assets/result-1.png"

    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logger.info(
        f"[{now}] Quiz 선택지 : {answers} "
        f"--> 민감:{scores['A'].get('sensitivity',0)}, 지성:{scores['A'].get('oily',0)}, "
        f"건성:{scores['A'].get('dry',0)}, 복합:{scores['A'].get('combination',0)}, "
        f"|| 스트레스:{scores['B'].get('stress',0)}, 환경영향:{scores['B'].get('environment',0)}, "
        f"|| 결과:{(a_type or '해당없음')}/{(b_type or '해당없음')} --> view: result-{code if code else '?'} .png"
    )

    return JsonResponse({
        "answers": answers,
        "a_type": a_type,
        "b_type": b_type,
        "code": code,
        "image": image,
        "scores": scores,
    }, status=200)
