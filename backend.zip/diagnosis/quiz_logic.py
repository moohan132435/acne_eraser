from __future__ import annotations
from typing import Dict, List, Tuple, Optional
from datetime import date

# CLASS A/B
A_CATEGORIES = ["sensitivity", "oily", "dry", "combination"]
B_CATEGORIES = ["stress", "environment"]

THRESHOLD_A: Dict[str, int] = {"sensitivity": 4, "oily": 3, "dry": 4, "combination": 4}
THRESHOLD_B: Dict[str, int] = {"stress": 2, "environment": 4}

RESULT_MAP: Dict[Tuple[str, str], int] = {
    ("sensitivity", "stress"): 1,
    ("sensitivity", "environment"): 2,
    ("oily", "stress"): 3,
    ("oily", "environment"): 4,
    ("dry", "stress"): 5,
    ("dry", "environment"): 6,
    ("combination", "stress"): 7,
    ("combination", "environment"): 8,
}

# ==========================
# 새 설문: Q3~Q12 (10문항) 가중치
# - 키: 문제번호(3..12) → 보기번호(1..4) → {"A":{...}, "B":{...}, "score": n}
# - PNG "BE 설문지 질문별..."의 화살표를 그대로 옮겨 적으세요.
# - 화살표 없으면 가중치 생략(=0)
# - 아래는 몇 줄만 예시로 넣어둠. (TODO 표에 맞게 채우기)
# ==========================
WEIGHTS_V2: Dict[int, Dict[int, Dict[str, Dict[str, int]]]] = {
    # Q3 (예시)
    3: {
        1: {"A": {"oily": 2}, "score": 2},
        2: {"A": {"combination": 1}, "score": 1},
        3: {"A": {"dry": 1}, "score": 1},
        4: {"A": {"sensitivity": 1}, "score": 1},
    },
    # Q4 (예시)
    4: {
        1: {"A": {"oily": 2}, "score": 2},
        2: {"A": {"combination": 1}, "score": 1},
        3: {"A": {"dry": 1}, "score": 1},
        4: {"A": {"sensitivity": 1}, "score": 1},
    },
    # Q5 (예시: 민감성 +1 이슈)
    5: {
        1: {"A": {"sensitivity": 2}, "score": 2},
        2: {"A": {"sensitivity": 1}, "score": 1},
        3: {"A": {"combination": 1}, "score": 1},
        4: {"score": 0},
    },
    # Q6 (예시: 스트레스/환경)
    6: {
        1: {"B": {"stress": 2}, "score": 2},
        2: {"B": {"stress": 1}, "score": 1},
        3: {"B": {"environment": 1}, "score": 1},
        4: {"score": 0},
    },
    # Q7 (예시)
    7: {1: {"A": {"dry": 1}, "B": {"environment": 1}, "score": 2},
        2: {"A": {"dry": 1}, "score": 1},
        3: {"score": 0},
        4: {"score": 0}},
    # Q8 (예시)
    8: {1: {"A": {"oily": 1}, "B": {"environment": 1}, "score": 2},
        2: {"B": {"stress": 1}, "A": {"sensitivity": 1}, "score": 2},
        3: {"B": {"environment": 2}, "score": 2},
        4: {"A": {"combination": 1}, "B": {"stress": 1}, "score": 2}},
    # Q9 (예시 → 점수만 혹은 0)
    9: {1: {"score": 0}, 2: {"score": 0}, 3: {"score": 0}, 4: {"score": 0}},
    # Q10/Q12: 성별별 보기(가중치는 동일, 이미지는 FE 분기)
    10: {
        1: {"A": {"oily": 1}, "B": {"environment": 1}, "score": 2},
        2: {"B": {"stress": 1}, "score": 1},
        3: {"A": {"sensitivity": 1}, "score": 1},
        4: {"score": 0},
    },
    11: {
        1: {"B": {"stress": 2}, "score": 2},
        2: {"A": {"sensitivity": 2}, "score": 2},
        3: {"A": {"sensitivity": 1}, "score": 1},
        4: {"score": 0},
    },
    12: {
        1: {"A": {"oily": 2}, "score": 2},
        2: {"A": {"dry": 2}, "score": 2},
        3: {"A": {"combination": 1}, "score": 1},
        4: {"score": 0},
    },
}
# ↑↑↑ 반드시 PNG의 화살표/점수대로 수정하세요.

def _acc(dst: Dict[str, int], add: Dict[str, int]) -> None:
    for k, v in add.items():
        dst[k] = dst.get(k, 0) + int(v)

def _select_if_threshold_met(scores: Dict[str, int], threshold: Dict[str, int], order: List[str]) -> Optional[str]:
    cands = [k for k in order if scores.get(k, 0) >= threshold.get(k, 10**9)]
    if not cands: return None
    return max(cands, key=lambda k: (scores.get(k, 0), -order.index(k)))

# 총점 → 상위백분위/나이보정 테이블
PERCENTILE_AGE_TABLE = [
    # (min_score, max_score, percentile, age_factor)
    (18,  99,   5,   0.70),   # -30%
    (16,  17,  10,   0.80),   # -20%
    (15,  15,  15,   0.85),   # -15%
    (13,  14,  20,   0.90),   # -10%
    (12,  12,  25,   0.95),   # -5%
    (10,  11,  50,   0.99),   # -1%
    (9,    9,  25,   1.05),   # +5%
    (8,    8,  20,   1.10),   # +10%
    (7,    7,  15,   1.15),   # +15%
    (6,    6,  10,   1.20),   # +20%
    (5,    5,   5,   1.25),   # +25%
]

def _map_total_to_percentile_and_factor(total: int) -> tuple[int, float]:
    for mn, mx, pct, fac in PERCENTILE_AGE_TABLE:
        if mn <= total <= mx:
            return pct, fac
    # 바운더리 밖이면 클램프
    if total < 5:  return 5, 1.25
    if total > 99: return 5, 0.70
    # 기본
    return 50, 1.0

def _calc_age_from_birth_year(birth_year: int) -> int:
    today = date.today()
    age = today.year - int(birth_year)
    return max(1, age)

def compute_result_v2(gender: str, birth_year: int, picks: List[int]) -> Dict:
    """
    gender: "M" | "W"
    birth_year: 4-digit year
    picks: length 10, Q3~Q12 각 1..4
    """
    if gender not in ("M", "W"):
        raise ValueError("invalid gender")
    if not isinstance(birth_year, int) or birth_year < 1900 or birth_year > 2025:
        raise ValueError("invalid birth_year")
    if not isinstance(picks, list) or len(picks) != 10 or not all(1 <= int(x) <= 4 for x in picks):
        raise ValueError("picks must be a 10-length array of 1..4")

    scores_a = {k: 0 for k in A_CATEGORIES}
    scores_b = {k: 0 for k in B_CATEGORIES}
    total_score = 0

    for i, ans in enumerate(picks):
        qnum = 3 + i  # 3..12
        cell = WEIGHTS_V2.get(qnum, {}).get(int(ans), {})

        if "A" in cell: _acc(scores_a, cell["A"])
        if "B" in cell: _acc(scores_b, cell["B"])
        total_score += int(cell.get("score", 0))

    # CLASS A/B → 코드
    a_type = _select_if_threshold_met(scores_a, THRESHOLD_A, A_CATEGORIES)
    b_type = _select_if_threshold_met(scores_b, THRESHOLD_B, B_CATEGORIES)
    code = RESULT_MAP.get((a_type, b_type)) if (a_type and b_type) else None

    # 총점→상위%/나이보정
    percentile, age_factor = _map_total_to_percentile_and_factor(total_score)
    real_age = _calc_age_from_birth_year(birth_year)
    skin_age = round(real_age * age_factor)

    return {
        "gender": gender,
        "birth_year": birth_year,
        "picks": picks,
        "scores": {"A": scores_a, "B": scores_b, "total": total_score},
        "a_type": a_type,
        "b_type": b_type,
        "code": code,
        "skin_age": skin_age,
        "skin_percentile": percentile
    }
