import React, { useContext } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { QuizContext } from "../context/QuizContext.jsx";
import LanguageSwitcher from "../components/LanguageSwitcher.jsx";

/* ===========================
   인라인 PercentPyramid 컴포넌트
   (별도 파일 없이 사용 가능)
=========================== */
function PercentPyramid({ age = 23, percent = 50, lang = "KOR" }) {
  const safePercent = Math.min(100, Math.max(0, Number(percent) || 0));
  const decadeStart = Math.floor((Number(age) || 20) / 10) * 10;
  const decadeLabel = lang === "ENG" ? `${decadeStart}s` : `${decadeStart}대`;

  // "상위 n%"일수록 채움이 많아지도록 반전
  const fillPct = 100 - safePercent; // 0~100
  const fillY = 100 - fillPct;       // SVG y 시작점

  const title1 =
    lang === "ENG"
      ? `Your skin age is ${age}.`
      : `당신의 피부나이는 ${age}살입니다.`;

  const title2 =
    lang === "ENG"
      ? `Top ${safePercent}% among people in their ${decadeLabel}.`
      : `${decadeLabel} 중에 상위 ${safePercent}% 입니다!`;

  return (
    <section
      className="pyramid-card"
      style={{
        border: "1px solid var(--border)",
        borderRadius: 12,
        padding: 16,
        margin: "12px 0",
        background: "#fff",
      }}
    >
      <div style={{ textAlign: "center", marginBottom: 12, lineHeight: 1.35 }}>
        <div
          style={{
            fontWeight: 800,
            fontSize: "clamp(16px, 4.3vw, 22px)",
            marginBottom: 6,
            color: "#0f172a",
          }}
        >
          {title1}
        </div>
        <div
          style={{
            fontWeight: 800,
            fontSize: "clamp(15px, 4vw, 20px)",
            color: "var(--brand)",
          }}
        >
          {title2}
        </div>
      </div>

      {/* SVG 피라미드 */}
      <div style={{ maxWidth: 420, margin: "0 auto" }}>
        <svg viewBox="0 0 100 100" width="100%" height="auto" role="img" aria-label={title2}>
          {/* 외곽선 */}
          <polygon points="50,5 95,95 5,95" fill="none" stroke="#6ee7e7" strokeWidth="1.8" />

          <defs>
            <clipPath id="pyramid-clip">
              <polygon points="50,5 95,95 5,95" />
            </clipPath>
            <linearGradient id="pyramid-grad" x1="0" y1="1" x2="0" y2="0">
              <stop offset="0%" stopColor="#d9f7ff" />
              <stop offset="60%" stopColor="#8be3f0" />
              <stop offset="100%" stopColor="#51d1e6" />
            </linearGradient>
          </defs>

          {/* 등분 가이드 */}
          {Array.from({ length: 4 }).map((_, i) => {
            const y = 95 - (i + 1) * ((95 - 5) / 5);
            return (
              <line key={i} x1="10" x2="90" y1={y} y2={y} stroke="#e6f6f1" strokeWidth="0.8" opacity="0.9" />
            );
          })}

          {/* 채움(clipPath로 피라미드 내부만 보이게) */}
          <g clipPath="url(#pyramid-clip)">
            <rect x="0" y={fillY} width="100" height={fillPct} fill="url(#pyramid-grad)" opacity="0.95" />
          </g>
        </svg>

        <div
          style={{
            textAlign: "center",
            marginTop: 8,
            color: "#334155",
            fontSize: "clamp(12px, 3.5vw, 14px)",
          }}
        >
          {lang === "ENG"
            ? `Fill shows Top ${safePercent}% (higher fill = better rank)`
            : `채움 영역은 상위 ${safePercent}%를 의미합니다`}
        </div>
      </div>
    </section>
  );
}

/* ===========================
   ResultPage
=========================== */
export default function ResultPage() {
  const nav = useNavigate();
  const { state, dispatch } = useContext(QuizContext);
  const { state: navState } = useLocation();
  const lang = state.lang || "KOR";

  // ===== 결과 복구 =====
  let result = state.result || navState?.result;
  if (!result) {
    try {
      const s = localStorage.getItem("result");
      if (s) result = JSON.parse(s);
    } catch {}
  }

  // 피부나이 / 백분위(상위 %) 기본값
  const skinAge = Number(
    (result && result.skin_age != null ? result.skin_age
      : (navState && navState.skin_age != null ? navState.skin_age
        : (localStorage.getItem("skin_age") ?? 23)))
  );

  const percentile = Number(
    (result && result.skin_percentile != null ? result.skin_percentile
      : (navState && navState.skin_percentile != null ? navState.skin_percentile
        : (localStorage.getItem("skin_percentile") ?? 20))) // 이 부분 변경하면 피라미드 수치 변함
  );

  // 결과 이미지(언어별)
  let imgSrc =
    result?.code != null
      ? `/assets/result-${result.code}.png`
      : result?.image || "/assets/result-1.png";
  if (lang === "ENG") imgSrc = imgSrc.replace(/(\.png)$/i, "_eng$1");

  // 다시하기(언어 유지)
  const retry = () => {
    const keepLang = state.lang;
    dispatch({ type: "RESET" });
    dispatch({ type: "SET_LANG", payload: keepLang });
    nav("/");
  };

  // ===== 공유: iOS는 이미지+URL 시도, 기타는 URL 복사 =====
  const BASE_URL = "https://acne-eraser.vercel.app";
  const ua = typeof navigator !== "undefined" ? navigator.userAgent : "";
  const isIOS = /iPad|iPhone|iPod/i.test(ua);

  const fetchAsFile = async (url) => {
    const resp = await fetch(url, { mode: "same-origin", cache: "no-cache" });
    if (!resp.ok) throw new Error("image fetch failed");
    const blob = await resp.blob();
    const filename = (url.split("/").pop() || "acne-result.png").replace(/\?.*$/, "");
    return new File([blob], filename, { type: blob.type || "image/png" });
  };

  const copyUrl = async (url) => {
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(url);
        return true;
      }
    } catch {}
    try {
      const ta = document.createElement("textarea");
      ta.value = url;
      ta.setAttribute("readonly", "");
      ta.style.position = "fixed";
      ta.style.top = "0";
      ta.style.left = "0";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.focus();
      ta.select();
      const ok = document.execCommand("copy");
      document.body.removeChild(ta);
      return ok;
    } catch {
      return false;
    }
  };

  const handleShare = async () => {
    if (isIOS) {
      try {
        const file = await fetchAsFile(imgSrc);
        if (navigator.canShare && navigator.canShare({ files: [file] }) && typeof navigator.share === "function") {
          await navigator.share({ title: "Spot Eraser", url: BASE_URL, files: [file] });
          return;
        }
      } catch {}
      try {
        if (typeof navigator.share === "function") {
          await navigator.share({ title: "Spot Eraser", url: BASE_URL });
          return;
        }
      } catch (err) {
        if (err && (err.name === "AbortError" || err.name === "NotAllowedError")) return;
      }
      const copied = await copyUrl(BASE_URL);
      alert(copied
        ? (lang === "ENG" ? "Link copied to clipboard." : "링크를 클립보드에 복사했어요.")
        : (lang === "ENG" ? "Sharing is not supported in this environment."
                          : "이 브라우저에서는 공유하기가 지원되지 않습니다."));
      return;
    }
    const copied = await copyUrl(BASE_URL);
    alert(copied
      ? (lang === "ENG" ? "Link copied to clipboard." : "링크를 클립보드에 복사했어요.")
      : (lang === "ENG" ? "Sharing is not supported in this environment."
                        : "이 브라우저에서는 공유하기가 지원되지 않습니다."));
  };

  // 결과 텍스트(이미지와 겹치지 않도록 이미지 위에 표시)
  const skinAgeText =
    lang === "ENG"
      ? `Your skin age is ${isFinite(skinAge) ? skinAge : 23}.`
      : `당신의 피부나이는 ${isFinite(skinAge) ? skinAge : 23}살입니다.`;

  return (
    <div className="page">
      <header className="topbar">
        <div className="brand">Spot Eraser</div>
        <LanguageSwitcher />
      </header>

      <div className="result-wrap" style={{ maxWidth: 720, margin: "0 auto" }}>
        {/* 피부나이 + 상위% + 피라미드 */}
        <PercentPyramid age={skinAge} percent={percentile} lang={lang} />

        {/* 결과 이미지 (텍스트와 겹치지 않음) */}
        <img
          src={imgSrc}
          alt={`result ${result?.code ?? ""}`}
          style={{ width: "100%", display: "block", borderRadius: 12 }}
          loading="lazy"
        />

        {/* 버튼: 세로 스택 */}
        <div
          className="result-actions"
          style={{ display: "flex", flexDirection: "column", gap: 12, marginTop: 16 }}
        >
          <a
            className="btn btn-lg insta-btn"
            href="https://www.instagram.com/pgb_global/"
            target="_blank"
            rel="noreferrer"
            style={{ width: "100%", display: "flex", justifyContent: "center" }}
          >
            {lang === "ENG" ? "Message on Instagram" : "인스타 DM 상담하기"}
          </a>

          <button className="btn btn-lg share-btn" onClick={handleShare} style={{ width: "100%" }}>
            {lang === "ENG" ? "Share" : "공유하기"}
          </button>

          <button className="btn btn-lg retry-btn" onClick={retry} style={{ width: "100%" }}>
            {lang === "ENG" ? "Retry" : "다시하기"}
          </button>
        </div>
      </div>
    </div>
  );
}
